-- ============================================
-- 七月开发模板 - 服务端主文件
-- ============================================

-- 初始化 ESX
ESX = exports["es_extended"]:getSharedObject()

-- 启动时执行
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    print('^2[七月模板] 资源已启动^0')
end)

-- 停止时执行
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    print('^1[七月模板] 资源已停止^0')
end)

-- ============================================
-- 服务器回调示例
-- ============================================

ESX.RegisterServerCallback('qy_template:checkItem', function(source, cb, itemName)
    local xPlayer = ESX.GetPlayerFromId(source)
    local item = xPlayer.getInventoryItem(itemName)
    
    if item.count >= 1 then
        cb(true)
    else
        cb(false)
    end
end)

-- ============================================
-- 服务端事件示例
-- ============================================

RegisterNetEvent('qy_template:serverAction', function(data)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    -- 权限检查
    if not CheckPermission(xPlayer) then
        TriggerClientEvent('ox_lib:notify', source, {
            type = 'error',
            description = '你没有权限'
        })
        return
    end
    
    -- 处理逻辑
    print('[七月模板] 玩家 ' .. xPlayer.getName() .. ' 执行了操作')
end)

-- ============================================
-- 工具函数
-- ============================================

function CheckPermission(xPlayer)
    for _, job in pairs(Config.AllowedJobs) do
        if xPlayer.job.name == job then
            return true
        end
    end
    return false
end

-- 数据库查询示例
function GetPlayerData(identifier)
    local result = MySQL.query.await('SELECT * FROM users WHERE identifier = ?', {identifier})
    return result[1]
end

-- 数据库插入示例
function SavePlayerData(identifier, data)
    MySQL.insert('INSERT INTO your_table (identifier, data) VALUES (?, ?)', {
        identifier,
        json.encode(data)
    })
end
