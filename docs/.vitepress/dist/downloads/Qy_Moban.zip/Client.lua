-- ============================================
-- 七月开发模板 - 客户端主文件
-- ============================================

-- 初始化 ESX
ESX = exports["es_extended"]:getSharedObject()
PlayerData = {}

-- 获取玩家数据
RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
end)

-- ============================================
-- 按键绑定
-- ============================================

RegisterKeyMapping('qy_template_menu', '打开七月模板菜单', 'keyboard', Config.Keys.OpenMenu)

RegisterCommand('qy_template_menu', function()
    OpenMenu()
end)

-- ============================================
-- 主菜单
-- ============================================

function OpenMenu()
    -- 使用 ox_lib 菜单
    lib.registerContext({
        id = 'qy_template_menu',
        title = '七月模板菜单',
        options = {
            {
                title = '选项 1',
                description = '这是第一个选项',
                icon = 'fa-solid fa-check',
                onSelect = function()
                    print('你选择了选项 1')
                end
            },
            {
                title = '选项 2',
                description = '这是第二个选项',
                icon = 'fa-solid fa-times',
                onSelect = function()
                    CheckItemAndDoAction()
                end
            }
        }
    })
    
    lib.showContext('qy_template_menu')
end

-- ============================================
-- 客户端事件示例
-- ============================================

RegisterNetEvent('qy_template:clientAction', function(data)
    -- Ox_Lib 通知
    lib.notify({
        title = '通知标题',
        description = '这是通知内容',
        type = 'success'
    })
end)

-- ============================================
-- 工具函数
-- ============================================

function CheckItemAndDoAction()
    ESX.TriggerServerCallback('qy_template:checkItem', function(hasItem)
        if hasItem then
            lib.notify({
                type = 'success',
                description = '你有这个物品'
            })
            -- 执行操作
            TriggerServerEvent('qy_template:serverAction', {})
        else
            lib.notify({
                type = 'error',
                description = '你没有这个物品'
            })
        end
    end, 'phone')
end

-- 绘制 3D 文本
function Draw3DText(coords, text)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    local camCoords = GetGameplayCamCoords()
    local distance = #(camCoords - coords)
    
    local scale = (1 / distance) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    scale = scale * fov
    
    if onScreen then
        SetTextScale(0.0 * scale, 0.55 * scale)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(x, y)
    end
end

-- 获取最近的玩家
function GetClosestPlayer()
    local players = GetActivePlayers()
    local closestDistance = -1
    local closestPlayer = -1
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    for _, player in ipairs(players) do
        local target = GetPlayerPed(player)
        
        if target ~= ped then
            local targetCoords = GetEntityCoords(target)
            local distance = #(targetCoords - coords)
            
            if closestDistance == -1 or closestDistance > distance then
                closestPlayer = player
                closestDistance = distance
            end
        end
    end

    return closestPlayer, closestDistance
end
