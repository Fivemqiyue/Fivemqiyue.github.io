fx_version 'adamant'
game 'gta5'
lua54 'yes'

description '自定义内容'
author '七月'
version '1.0.0'

-- 依赖资源
dependencies {
    'es_extended',
    'ox_lib'
}

-- 服务端脚本
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*.lua'
}

-- 客户端脚本
client_scripts {
    'client/*.lua'
}

-- 共享脚本
shared_scripts {
    '@es_extended/imports.lua',
    '@es_extended/locale.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

-- UI 文件
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/img/*.png'
}

-- 加密忽略文件
escrow_ignore {
    'config.lua',
    'locales/*.lua'
}
