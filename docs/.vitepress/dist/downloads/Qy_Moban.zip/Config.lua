Config = {}

-- 基础配置
Config.Locale = 'zh'  -- 语言设置
Config.Debug = false  -- 调试模式

-- ESX 配置
Config.ESX = {
    Framework = 'es_extended',
    UseNewESX = true,  -- 使用 ESX 1.9.0+ 新版本
}

-- Ox_Lib 配置
Config.UseOxLib = true

-- Ox_Inventory 配置  
Config.UseOxInventory = true

-- UI 配置
Config.UI = {
    Position = 'right-center',  -- UI 位置
    ShowNotification = true,     -- 显示通知
}

-- 按键配置
Config.Keys = {
    OpenMenu = 'F6',  -- 打开菜单
}

-- 权限配置
Config.AllowedJobs = {
    'police',
    'ambulance',
    'mechanic'
}

-- 其他自定义配置
Config.Settings = {
    MaxDistance = 10.0,  -- 最大交互距离
    RefreshTime = 5000,  -- 刷新时间（毫秒）
}
